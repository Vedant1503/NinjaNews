from django.apps import AppConfig


class DailyexpressConfig(AppConfig):
    name = 'ninjaexpress'
